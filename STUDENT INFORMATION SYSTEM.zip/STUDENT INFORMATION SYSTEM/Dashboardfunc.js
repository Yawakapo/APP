// 1. Unique id of the 2 buttons
const btndashboard = document.getElementById("dashboard");
const btnstudents = document.getElementById("students");

// 2. For the dashboardview and student view id
const Dashboardview = document.getElementById("Dashboardview");
const studentsView = document.getElementById("studentsView");

// 3. Add click event listener for the Dashboard button
btndashboard.addEventListener("click", () => {
  // Show Dashboard, Hide Students
  Dashboardview.style.display = "block";
  studentsView.style.display = "none";

  // Update active button highlights
  btndashboard.classList.add("active");
  btnstudents.classList.remove("active");
});

// 4. Add click event listener for the Students button
    btnstudents.addEventListener("click", () => {
  // Hide Dashboard, Show Students
     Dashboardview.style.display = "none";
    studentsView.style.display = "block";

  // Update active button highlights
     btnstudents.classList.add("active");
     btndashboard.classList.remove("active");
});






