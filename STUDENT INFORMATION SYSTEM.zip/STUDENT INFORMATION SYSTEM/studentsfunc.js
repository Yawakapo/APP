

document.addEventListener("DOMContentLoaded", () => {
  renderStudentList();
});

function renderStudentList() {
  const container = document.getElementById("studentContainer");
  const filterSelect = document.getElementById("courseFilter");

  if (!container) return;

  const selectedCourse = filterSelect ? filterSelect.value : "All";
  container.innerHTML = "";

  const filtered = selectedCourse === "All" 
    ? students 
    : students.filter(s => s.course === selectedCourse);

  if (filtered.length === 0) {
    container.innerHTML = `<p style="padding: 15px; color: #94a3b8;">No students found for this course.</p>`;
    return;
  }

  filtered.forEach(student => {
    const row = document.createElement("div");
    row.className = "student-row";

    const badgeClass = student.status === "Active" ? "badge-active" : "badge-dropped";

    // --- Changing of id inside of student directory ---
    row.innerHTML = `
      <div class="student-details">
      
        <h4>${student.name}</h4>
        <p>Course: ${student.course}</p>
      </div>
      <div class="student-status">
        <span class="status-badge ${badgeClass}">${student.status}</span>
      </div>
    `;

    container.appendChild(row);
  });
}

function filterStudents() {
  renderStudentList();
}